# CoolMind

Run powerful AI models locally without overheating your PC.

## Features

- Dynamic model offloading to CPU/RAM when GPU thermal thresholds are approached
- Intelligent quantization based on real-time temperature monitoring
- Low-latency inference with thermal-aware batching
- Cross-platform support (Windows, Linux, macOS)
- Plugin architecture for custom cooling strategies

## Installation

```bash
git clone https://github.com/yourusername/CoolMind.git
cd CoolMind
pip install -r requirements.txt
```

## Usage

```python
from coolmind import CoolEngine

engine = CoolEngine(max_temp=75)  # Celsius
response = engine.generate("Explain quantum computing simply")
print(response)
```

## License

MIT
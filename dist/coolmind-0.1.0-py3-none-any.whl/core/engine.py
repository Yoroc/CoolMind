import torch
import psutil
import time
import threading
from typing import Optional, Callable
from dataclasses import dataclass

@dataclass
class ThermalConfig:
    max_gpu_temp: float = 80.0
    check_interval: float = 2.0
    offload_threshold: float = 75.0
    cooldown_threshold: float = 65.0

class CoolEngine:
    def __init__(self, model_name: str = "gpt2", thermal_config: Optional[ThermalConfig] = None):
        self.model_name = model_name
        self.config = thermal_config or ThermalConfig()
        self._monitoring = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._current_temp = 0.0
        self._model = None
        self._tokenizer = None
        self._load_model()

    def _load_model(self):
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self._tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self._model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            torch_dtype=torch.float16,
            device_map="auto"
        )

    def _monitor_temperature(self):
        while self._monitoring:
            gpus = psutil.sensors_temperatures().get('coretemp', [])
            if gpus:
                self._current_temp = max([entry.current for entry in gpus if entry.current], default=0.0)
                if self._current_temp > self.config.offload_threshold:
                    self._offload_to_cpu()
                elif self._current_temp < self.config.cooldown_threshold and self._model.device.type == 'cpu':
                    self._reload_to_gpu()
            time.sleep(self.config.check_interval)

    def _offload_to_cpu(self):
        if self._model.device.type != 'cpu':
            self._model = self._model.to('cpu')

    def _reload_to_gpu(self):
        if torch.cuda.is_available() and self._model.device.type == 'cpu':
            self._model = self._model.to('cuda')

    def generate(self, prompt: str, max_length: int = 50) -> str:
        inputs = self._tokenizer(prompt, return_tensors="pt").to(self._model.device)
        with torch.no_grad():
            outputs = self._model.generate(**inputs, max_length=max_length)
        return self._tokenizer.decode(outputs[0], skip_special_tokens=True)

    def start_monitoring(self):
        if not self._monitoring:
            self._monitoring = True
            self._monitor_thread = threading.Thread(target=self._monitor_temperature, daemon=True)
            self._monitor_thread.start()

    def stop_monitoring(self):
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)